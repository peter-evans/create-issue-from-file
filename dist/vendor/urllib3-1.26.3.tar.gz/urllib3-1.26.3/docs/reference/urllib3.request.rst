Request Methods
===============

.. automodule:: urllib3.request
    :members:
    :undoc-members:
    :show-inheritance:
