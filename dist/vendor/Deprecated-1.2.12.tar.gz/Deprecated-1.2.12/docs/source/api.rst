.. _api:

API
===

This part of the documentation covers all the interfaces of the Deprecated Library.

.. automodule:: deprecated
   :members:

.. automodule:: deprecated.classic
   :members:

.. automodule:: deprecated.sphinx
   :members:
