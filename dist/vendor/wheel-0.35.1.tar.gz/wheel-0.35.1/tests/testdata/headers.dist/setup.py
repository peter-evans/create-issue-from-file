from setuptools import setup

setup(name='headers.dist',
      version='0.1',
      description=u'A distribution with headers',
      headers=['header.h']
      )
